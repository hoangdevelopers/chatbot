// use here your library name
module.exports = require('./dist/Greeter')