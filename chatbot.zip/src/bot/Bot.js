import { textFillter, cmdFillter, shortCodeFillter } from '../fillter/index'


export class Bot {
    constructor({my_id, my_name}) {
        this.my_id = my_id
        this.my_name = my_name
    }

    get() {
        return this.output
    }
    set({ input, sender_id, sender_name }) {
        this.input = input
        this.sender_id = sender_id
        this.sender_name = sender_name

        this.output = ""
        var currentdate = new Date();
        var dayName = new Array("Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy")
        this.time = currentdate.getHours() + ":"
            + currentdate.getMinutes() + ":"
            + currentdate.getSeconds();
        this.day = dayName[currentdate.getDay()]
        return this
    }
    _think(text) {
        var result = false
        var cmd_fillter = new cmdFillter(text)
        var short_code_fillter = new shortCodeFillter(text)
        var text_fillter = new textFillter(text)
        var list_fillter = []
        console.log(this.my_id, this.sender_id)
        if (this.my_id === this.sender_id) list_fillter = [cmd_fillter, short_code_fillter]
        else list_fillter = [short_code_fillter, text_fillter]

        list_fillter.forEach((el) => {
                if (el.fill().isMatch()) {
                    result = el.get()
                    return
                }
            });
        return result
    }
    reply() {
        var think = this._think(this.input)
        if (think) {
            if (think.TYPE === "TEXT") think.value = this._replace(think.value)
            this.output = think
        }
        else{
            var rd = Math.floor((Math.random() * 20) + 1);
            if (rd == 3) {
                res = "gõ @help để xem hd"
                api.sendMessage(res, event.threadID);
            }
        }
        return this
    }
    _replace(text) {
        text.replace(/@yourname/g, this.sender_name);
        text.replace(/@myname/g, this.my_name);
        text.replace(/@nowtime/g, this.time);
        text.replace(/@nowday/g, this.day);
        return text
    }
}