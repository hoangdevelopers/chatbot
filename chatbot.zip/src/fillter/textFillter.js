import { Ultilities } from '../lib/index'
import { data } from './constants'
require("string_score");

export class textFillter {
    constructor(str) {
        this.input = str
        this.result = ""
        this.match = false
    }
    fill() {
        var max_core = 0
        var obj = null
        data.forEach((data_row) => {
            var inputs = data_row.input
            var score = 0
            inputs.forEach((input_row) => {
                score += input_row.score(this.input)
            })
            if (score / inputs.length > max_core) {
                max_core = score
                obj = data_row
            }
        })
        if (obj !== null) {
            this.match = true
            this.result = {
                type: "TEXT",
                value: obj.output
            }
        }
        return this
    }
    isMatch() {
        return this.match
    }
    get() {
        return this.result
    }
}