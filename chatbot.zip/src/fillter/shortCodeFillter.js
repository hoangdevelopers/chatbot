import { Ultilities } from '../lib/index'

export class shortCodeFillter {
    constructor(str) {
        this.input = str
        this.result = ""
        this.match = false
    }
    fill() {
        if (this.input.indexOf("@img") !== -1) {
            this.match = true
            var key = this.input.substring(4, this.input.length)
            this.result = {
                type: "IMG",
                value: { src: "FLICKR", key: key , text: ""}
            }
        }
        else if (this.input === "@gai" || this.input === "@girl" || this.input === "@fap") {
            this.match = true
            this.result = {
                type: "IMG",
                value: { src: "FACEBOOK", key: null, text: "Cái đồ dại gái =))" }
            }
        }
        else if (this.input === "@help") {
            this.match = true
            this.result = {
                type: "TEXT",
                value: `Do bot mới được phát triển nên chỉ có 1 số tính năng sau:\n1. Hỏi linh tinh (Dang dev).\n2. Chém gió vui.\n3. Xem hình gái xinh với cú pháp @gái, @fap).\n4. Tìm nhạc với cú pháp @music (@music sơn tùng)\n`
            }
        }

        return this
    }
    isMatch() {
        return this.match
    }
    get() {
        return this.result
    }
}