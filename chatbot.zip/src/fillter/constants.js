const data = [
    {
        "input": ["blabala", "bla bla"],
        "output": "xàm xí"
    },
    {
        "input": ["xin chao hi hello alo"],
        "output": "chào @yourname"
    },
    {
        "input": ["ban ten la gi"],
        "output": "đại ca là @myname"
    },
    {
        "input": ["cut", "dm", "dau ma", "dcm", "vkl", "vl", "du ma", "bi dien", "bo lao", "me may", "ccmm", "ccmn", "fuck", "con cac"],
        "output": "mất dạy"
    },
    {
        "input": ["la sao"],
        "output": "Anh không biết bao nhiêu sao trên trời?"
    },
    {
        "input": ["khong hieu", "k hieu", "khong biet", "k biet"],
        "output": "Hiểu sao được?"
    },
    {
        "input": ["choi khong", "choi ko", "choi"],
        "output": "ko, có việc r"
    },
    {
        "input": ["bot tu dong", "botchat", "bot chat"],
        "output": "đúng rồi mình là chat bot của anh hoàng đẹp trai"
    },
    {
        "input": [":))", "=))"],
        "output": "cười cái gì"
    },
    {
        "input": [":((", "=(("],
        "output": "nín"
    },
    {
        "input": [":P"],
        "output": "nàm thao"
    },
    {
        "input": ["khong biet", "k biet"],
        "output": "tại sao phải biết"
    },
    {
        "input": [":v"],
        "output": ":)"
    },
    {
        "input": ["sao phai"],
        "output": "ý kiến gì"
    },
    {
        "input": ["ngu", "dot"],
        "output": "@yourname cũng vậy :v"
    },
    {
        "input": ["bot kem", "may kem"],
        "output": "từ từ sẽ gỏi"
    },
    {
        "input": ["kaka", "kk"],
        "output": "có gì vui?"
    },
    {
        "input": ["may gio", "bay gio", "may gio rui", "may gio roi"],
        "output": "bây giờ là @nowtime"
    },
    {
        "input": ["hom nay", "ngay nao", "thu may"],
        "output": "hôm nay là @nowday"
    },
    {
        "input": ["di lam", "dang lam", "lam gi", "lam j"],
        "output": "đang ở nhà ăn bám"
    },
    {
        "input": ["dang lam gi"],
        "output": "ngồi trả lời tin nhắn @yourname thôi"
    },
    {
        "input": ["password", "mat khau"],
        "output": "*******"
    },
    {
        "input": ["hoang", "a hoang", "e ku", "m oi"],
        "output": "a đây"
    },
    {
        "input": ["e oi"],
        "output": "e nào"
    },
    {
        "input": ["cho hoi", "hoi cai"],
        "output": "cái j a cũng không biết trừ ngày giờ là a biết"
    },
    {
        "input": ["?", "??", "hoi cham"],
        "output": "thắc mắc lên phường"
    },
    {
        "input": [":3"],
        "output": "B-)"
    },
    {
        "input": ["ngu hoc", "oc cho"],
        "output": "@yourname óc chó"
    },
    {
        "input": ["cam on", "thank", "nice", "hay qua", "gioi qua", "good job", "hay nhi", "hay ghe"],
        "output": "Không có chi. Rất vui vì đã giúp được cho @yourname ^_^"
    }

]
export { data }